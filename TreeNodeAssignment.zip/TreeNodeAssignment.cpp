#include<stdio.h>
#include<string.h>
#include<stdlib.h>

#define MAX_WORD_SIZE 5

typedef struct{
	char word[MAX_WORD_SIZE];
}NodeData;

typedef struct treenode{
	NodeData data;
	struct treenode* left;
	struct treenode* right;
}TreeNode;

typedef struct{
	TreeNode* root;
}BinaryTree;


TreeNode* buildTree(char* ch){
	int x=0;
	int cnt;
	int length = strlen(ch);		
	char *pointer = "@";
	
	if (*ch >= 'A' && *ch <= 'Z' ){
			  cnt = 1;
	}

	else if (*ch >= 'a' && *ch <= 'z'){
			cnt = 1;
	}
	
  	else{
  			cnt = 0;
	  }


	
	if(cnt !=1 || strcmp(pointer,ch)==0){
		return NULL;
	}
	

	TreeNode* p=(TreeNode*)malloc(sizeof(TreeNode));
	
	strcpy(p->data.word,ch);
	
	if(*ch != '\0'){
		*ch++;
	}
	
	p->left=buildTree(ch);
	p->right=buildTree(ch);
	return p;
}


void visit(TreeNode *node){
	printf("%s ",node->data.word);
}

void inOrder(TreeNode* node) { 
	if (node != NULL) {
	inOrder(node->left); 
 	printf("%s ", node->data.word); 
    inOrder(node->right);
	} 
}


void preOrder(TreeNode* node){
	if(node!=NULL){
		visit(node);
		preOrder(node->left);
		preOrder(node->right);		
	}
	
}

int numNodes(TreeNode* root){
	if(root==NULL){
		return 0;
	}
	else{
		return 1+numNodes(root->left)+numNodes(root->right);
	}
}

int main(){
	
	BinaryTree br;
	char ch[10];
	
	printf("Input up to 10 Word: \n");
	scanf("%s",ch);
	br.root=buildTree(ch);
	preOrder(br.root);
	

	return 0;
}
